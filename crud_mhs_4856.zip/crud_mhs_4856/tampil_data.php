<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CRUD 22.11.4856</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <h1 class="text-center my-5">CRUD PRODUCT</h1>
        <div class="d-flex justify-content-end m-3">
            <a href="form_tambah.php" class="btn btn-sm btn-primary">Tambah Product</a>
        </div>
        <table class="table table-striped text-center">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Product</th>
                    <th>Jenis Product</th>
                    <th>Jumlah Product</th>
                    <th>Keterangan Product</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                include 'service/koneksi.php';
                $sql = "SELECT * FROM product";
                $result = mysqli_query($link, $sql);
                while ($row = mysqli_fetch_object($result)) { ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= $row->nama_product ?></td>
                        <td><?= $row->jenis_product ?></td>
                        <td><?= $row->jumlah_product ?></td>
                        <td><?= $row->keterangan_product ?></td>
                        <td>
                            <a href="form_edit.php?id_product=<?= $row->id_product; ?>" class="btn btn-sm btn-success text-white">Edit</a>
                            <a class="btn btn-sm btn-danger text-white" href="service/delete.php?id_product=<?= $row->id_product; ?>">Delete</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>