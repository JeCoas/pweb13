<?php
$config = mysqli_connect("localhost", "root", "", "crud_mhs_4856");
if (!$config) {
    die('Gagal terhubung ke MySQLi : ' . mysqli_connect_error());
}
