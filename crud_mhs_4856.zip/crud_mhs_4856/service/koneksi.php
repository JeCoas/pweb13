<?php

$link = mysqli_connect('localhost', 'root', '');

mysqli_select_db($link, 'crud_mhs_4857');