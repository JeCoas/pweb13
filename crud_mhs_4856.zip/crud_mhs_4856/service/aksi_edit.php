<?php

include 'koneksi.php';

$id_product = $_POST['id_product'];
$nama_product = $_POST['nama_product'];
$jenis_product = $_POST['jenis_product'];
$jumlah_product = $_POST['jumlah_product'];
$keterangan_product = $_POST['keterangan_product'];


$sql = "UPDATE product SET nama_product='$nama_product', jenis_product='$jenis_product', jumlah_product='$jumlah_product', keterangan_product='$keterangan_product' WHERE id_product='$id_product'";

if (mysqli_query($link, $sql)) {
    header('location:../tampil_data.php');
} else {
    header('location:../form_tambah.php');
}
