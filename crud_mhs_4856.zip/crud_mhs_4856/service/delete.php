<?php
include 'koneksi.php';

$id_product = $_GET['id_product'];

$sql = "DELETE FROM product WHERE id_product='$id_product'";

if (mysqli_query($link, $sql)) {
    header('location:../tampil_data.php');
}
