<?php

include 'koneksi.php';



$nama_product = $_POST['nama_product'];
$jenis_product = $_POST['jenis_product'];
$jumlah_product = $_POST['jumlah_product'];
$keterangan_product = $_POST['keterangan_product'];


$sql = "INSERT INTO product(nama_product, jenis_product, jumlah_product, keterangan_product) VALUES('$nama_product', '$jenis_product', '$jumlah_product', '$keterangan_product')";

if (mysqli_query($link, $sql)) {
    header('location:../tampil_data.php');
} else {
    header('location:../form_tambah.php');
}
